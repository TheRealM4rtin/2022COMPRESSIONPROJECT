struct NodePath
{
    char* c;
    struct NodePath *next;
};

//========================================================================================================//

double compressionRate(char *fileNAME, char *compNAME);

//========================================================================================================//

void BlankRemovalComp(char *fileNAME, char * baseCompNAME, char * pathTemp, double * compressRate);

void RLEComp(char *fileNAME, char *baseCompNAME, char *pathTemp, double * compressRate);

//========================================================================================================//

void print(struct NodePath *head);

void PushPath(struct NodePath **head, char* data);

//========================================================================================================//

void comparison(struct NodePath *head, char * pathHeader, char * nameFile);

//========================================================================================================//

void traversal(char *originPath, char * PathHeader);