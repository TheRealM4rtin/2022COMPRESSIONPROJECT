#include "header.h"
#include <stdio.h>
#include <stdlib.h>

//========================================================================================================//

int main()
{
    system("mkdir ~/Desktop/FCtemporary");
    system("touch ~/Desktop/FCtemporary/header.txt");
    system("chmod +rw ~/Desktop/FCtemporary/header.txt");
    system("touch ~/Desktop/FCtemporary/stat.txt");

    char username[50];
    printf("Please enter the session's user name : ");
    scanf("%s", username);

    char PathHeader[555]="";
    sprintf(PathHeader, "/home/%s/Desktop/FCtemporary/header.txt", username);
    //clean the header file text from last writtings
    fclose(fopen(PathHeader, "w"));

    char PathStat[555]="";
    sprintf(PathStat, "/home/%s/Desktop/FCtemporary/stat.txt", username);
    //clean the stat file text from last writtings
    fclose(fopen(PathStat, "w"));

    //string to temporary file, to store different compression etc.
    char fileTemp[555]="";
    sprintf(fileTemp, "/home/%s/Desktop/FCtemporary", username);

    //string to put the path of the user
    char path[50]="";
    printf("Please enter path the folder : ");
    scanf("%s", path);

    //fonction to get all the files to compress in the folder chosen
    traversal(path, fileTemp);

    return 0;
}